sentence = "This is a test"

new_sentence = sentence.replace("s", "z")

print(new_sentence)