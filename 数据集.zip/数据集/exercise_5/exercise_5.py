#!/usr/bin/python3
l = []
for i in range(3):
    x = int(input("integer:\n"))
l.append(x)
l.sort()
print(l)
