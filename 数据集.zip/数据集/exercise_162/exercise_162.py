sentence = "This is a test. It demonstrates splitting strings."

split_by_spaces = sentence.split()
split_by_dot = sentence.split(".")
split_by_letter_s = sentence.split("s")

print(f"Split by spaces: {split_by_spaces}")
print(f"Split by dots: {split_by_dot}")
print(f"Split by letter 's': {split_by_letter_s}")