quote1 = "Then he said 'I will miss you'."
quote2 = 'Then he said "I will miss you".'

print(quote1)
print(quote2)