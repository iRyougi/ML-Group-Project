#!/usr/bin/python
# -*- coding: UTF-8 -*-
a = ["one", "two", "three"]
for i in a[::-1]:
    print(i)
