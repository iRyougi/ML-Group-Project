numbers = [1, 2, 3]

x, y, z = numbers

print(x)
print(y)
print(z)