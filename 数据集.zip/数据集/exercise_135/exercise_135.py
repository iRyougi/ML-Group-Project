from random import randint

# Print 10 random numbers between 1-100
for _ in range(10):
    print(randint(1,100))