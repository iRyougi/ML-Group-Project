s1 = "This"
s2 = "is"
s3 = "a test"

sentence = " ".join([s1, s2, s3])

print(sentence)