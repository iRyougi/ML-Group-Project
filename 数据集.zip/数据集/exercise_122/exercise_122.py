word = input("Give a word, I will reverse it: ")

print(word[::-1])