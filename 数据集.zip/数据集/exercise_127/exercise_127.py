names = ["Alice", "Bob", "Charlie"]

longest = max(names, key=len)

print(f"The longest name is {longest}")