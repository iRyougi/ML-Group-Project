data = {"Alice": 23, "Bob": 54, "Charlie": 12}

ages = data.values()

max_age = max(ages)

print(f"The oldest person is {max_age} years old.")