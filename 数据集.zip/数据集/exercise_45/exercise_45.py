
#!/usr/bin/python
# -*- coding: UTF-8 -*-
tmp = 0
for i in range(1,101):
    tmp += i
print ('The sum is %d' % tmp)
