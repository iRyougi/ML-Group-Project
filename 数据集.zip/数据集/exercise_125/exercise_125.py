import winsound

frequency = 2500  # High pitch 2500HZ beep
duration = 1000  # Duration of the beep is 1s

winsound.Beep(frequency, duration)