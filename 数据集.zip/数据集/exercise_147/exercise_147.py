names = ["Alice", "Bob", "Charlie", "David"]

for index, name in enumerate(names):
    print(f"At position {index} is {name}")