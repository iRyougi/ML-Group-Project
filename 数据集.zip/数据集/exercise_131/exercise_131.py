def as_pounds(kilos):
    return 2.2048 * kilos
    
kg = 80
pounds = as_pounds(kg)

print(f"{kg} is {pounds} in pounds")
