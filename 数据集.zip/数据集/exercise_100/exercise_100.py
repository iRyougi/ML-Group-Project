
#!/usr/bin/python
# -*- coding: UTF-8 -*-
i = ['a', 'b']
l = [1, 2]
print dict([i,l])
