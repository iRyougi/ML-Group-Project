names = ["Bob", "Charlie", "David"]

names.insert(0, "Alice")

print(names)