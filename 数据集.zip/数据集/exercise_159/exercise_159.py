from math import pi

print(f"Pi is {round(pi, 2)} when rounded to 2 decimals.")