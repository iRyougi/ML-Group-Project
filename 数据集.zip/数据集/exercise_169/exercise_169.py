name = "alice"

name_cap = name.upper()

print(name_cap)