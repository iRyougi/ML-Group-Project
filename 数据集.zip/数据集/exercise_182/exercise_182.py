from random import randint

def throw_dice():
    return randint(1, 6)

print(throw_dice())