#!/usr/bin/python
# -*- coding: UTF-8 -*-
x2 = 1
for day in range(9, 0, -1):
    x1 = (x2 + 1) * 2
x2 = x1
print(x1)
