# A function that filters even numbers
def filter_even(numbers):
    result = []
    for number in numbers:
        if number % 2 == 0:
            result.append(number)
    return result


# Example run
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

even_nums = filter_even(numbers)

print(even_nums)