sentence = "This is just a test"
target = "just"

idx = sentence.find(target)

print(f"The word '{target}'' starts at index {idx} in '{sentence}'")