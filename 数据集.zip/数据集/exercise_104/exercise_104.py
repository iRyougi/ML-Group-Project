sentence = "Hello, this is a sentence."

no_spaces = sentence.replace(" ", "")

print(no_spaces)