string = "This is a test"

snake = string.replace(" ", "_")

print(snake)