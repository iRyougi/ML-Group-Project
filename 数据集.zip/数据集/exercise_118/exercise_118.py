from math import sqrt, dist

start = (1, 1)
end = (2, 2)

dist = dist(start, end)

print(f"The distance between {start} and {end} is {dist}")