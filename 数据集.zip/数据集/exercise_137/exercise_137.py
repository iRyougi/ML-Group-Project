number = 3

# Odd = not divisible by 2
# Even = divisible by 2
is_odd = True if number % 2 != 0 else False

print(is_odd)