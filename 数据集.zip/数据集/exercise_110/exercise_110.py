n1 = 10
n2 = 100

minimum = min(n1, n2)

print(f"The minimum number is {minimum}")