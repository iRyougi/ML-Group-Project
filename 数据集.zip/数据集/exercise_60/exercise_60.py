
#!/usr/bin/python
# -*- coding: UTF-8 -*-
sStr1 = 'strlen'
print len(sStr1)
