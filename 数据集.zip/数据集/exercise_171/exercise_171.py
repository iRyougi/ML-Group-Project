age = 20

age_group = "adult" if age >= 18 else "minor"

print(age_group)