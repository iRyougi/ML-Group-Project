pizza_slices = 11
participants = 3

left_overs = pizza_slices % participants

print(f"{left_overs} slices are left over.")