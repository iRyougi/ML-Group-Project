from math import pi

# A function to find the area of a circle
def circle_area(r):
    return pi * r ** 2

radius = 5

print(f"A circle of radius {radius} takes {circle_area(radius)} square meters of space.")