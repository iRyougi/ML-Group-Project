character = "A"

char_ASCII = ord(character)

print(f"The ascii value of '{character}' is {char_ASCII}")