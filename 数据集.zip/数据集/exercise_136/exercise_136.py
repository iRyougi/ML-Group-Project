from random import choice

names = ["Alice", "Bob", "Charlie", "David"]

rand_name = choice(names)

print(rand_name)