year_seconds = 365.25 * 24 * 60 * 60

print(f"There are {year_seconds} in a year.")