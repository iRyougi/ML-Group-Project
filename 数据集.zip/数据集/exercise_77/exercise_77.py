
#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
if __name__ == '__main__':
    s = ["man","woman","girl","boy","sister"]
for i in range(len(s)):
        print s[i]
