#!/usr/bin/python
# -*- coding: UTF-8 -*-
a = [1, 2, 3]
b = a[:]
print(b)
