def greet(name="there"):
    print(f"Hello, {name}!")
    
greet()
greet("Alice")