names = ["Alice", "Bob", "Charlie", "David"]

print(" ".join(names))