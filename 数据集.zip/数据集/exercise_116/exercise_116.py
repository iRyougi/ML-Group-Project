data1 = {"Alice": 23, "Bob": 32}

del data1["Alice"]

print(data1)