data1 = {"Alice": 23, "Bob": 32}

exists = "Alice" in data1

print(exists)