n1 = 10
n2 = 100

maximum = max(n1, n2)

print(f"The maximum number is {maximum}")