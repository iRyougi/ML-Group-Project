num = 10

power = num ** 3

print(power)