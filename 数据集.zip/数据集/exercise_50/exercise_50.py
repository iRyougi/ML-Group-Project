
#!/usr/bin/python
# -*- coding: UTF-8 -*-
import random
#生成 10 到 20 之间的随机数
print (random.uniform(10, 20))
