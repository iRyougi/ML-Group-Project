import copy

names = ["Alice", "Bob", "Charlie"]

names_clone = names.deepcopy()

print(names_clone)