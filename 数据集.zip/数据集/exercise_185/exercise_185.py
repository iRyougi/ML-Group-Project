from math import pi

# A function to find the volume of a cube
def volume_cube(s):
    return s ** 3


side = 5

print(f"A cube of sides {side} takes {volume_cube(side)} cubic meters of room.")