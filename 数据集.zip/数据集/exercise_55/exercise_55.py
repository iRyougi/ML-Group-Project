
#!/usr/bin/python
# -*- coding: UTF-8 -*-

a = 7
b = ~a

c = -7
d = ~c

print ('变量 a 取反结果为： %d' % b)
print ('变量 c 取反结果为： %d' % d)
