numbers1 = [1, 2, 3]
numbers2 = [4, 5, 6]

merged = numbers1 + numbers2

print(merged)